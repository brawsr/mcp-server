# brawsr TypeScript SDK

The official Node.js client for brawsr sessions, checkpoints, rewind, fork, and CDP
handoff. It turns asynchronous API operations into one bounded method call; it
does not bundle or proxy a browser library.

Status: pre-release and not yet published to a registry. Requires Node.js 20+
and standards-compatible `fetch`.

## Install

```bash
npm install @brawsr/sdk
```

Install your browser client separately, for example:

```bash
npm install playwright-core
# or
npm install puppeteer-core
```

## Session and browser connection

```ts
import { chromium } from "playwright-core";
import { BrawsrClient, BrawsrWaitTimeoutError } from "@brawsr/sdk";

const brawsr = new BrawsrClient({
  apiKey: process.env.BRAWSR_API_KEY!,
  baseUrl: process.env.BRAWSR_BASE_URL!,
});

const session = await brawsr.createSession({ ttlSeconds: 300 });
const connection = brawsr.connectCDP(session);
const browser = await chromium.connectOverCDP(connection.endpointUrl, {
  headers: connection.headers,
});
```

`connectCDP` returns immutable connection data. The SDK does not retain the API
key in a browser object or speak CDP itself.

## Checkpoint and rewind

```ts
const checkpoint = await brawsr.createCheckpoint(session.id, {
  label: "before-submit",
  timeoutMs: 30_000,
});
await brawsr.waitCheckpoint(checkpoint.operationId);

// Continue browser work. This state is intentionally newer than the checkpoint.
await page.fill("textarea", "draft that should be discarded");

// A label, checkpoint ID, Checkpoint, or CheckpointResult is accepted.
const restored = await brawsr.rewind(session.id, checkpoint);

// Rewind replaces the browser process. The old Browser/Page handles are stale.
// Connect again and rediscover the default context and its pages.
const connection = brawsr.connectCDP(restored);
const restoredBrowser = await chromium.connectOverCDP(connection.endpointUrl, {
  headers: connection.headers,
});
const restoredContext = restoredBrowser.contexts()[0];
const restoredPages = restoredContext.pages();

// The early rewind result is already CDP-usable. Wait only before another
// lifecycle mutation on this same session (for example checkpoint or close).
await brawsr.waitRewind(restored.operationId);
```

`createCheckpoint`, `rewind`, `fork`, and `deleteCheckpoint` each send one mutation.
When the API returns `202 Accepted`, the SDK polls only the operation resource
and returns the final result. Callers do not need to implement polling.

Checkpoint labels are case-sensitive and unique among live checkpoints in a
session. A label that has the checkpoint-ID shape is rejected; use the returned
ID when an immutable reference is required.

## Resources and operations

- `createSession`, `getSession`, `closeSession`
- `createCheckpoint`, `getCheckpoint`, `listCheckpoints`, `iterateCheckpoints`,
  `deleteCheckpoint`
- `rewind`
- `fork`, `closeSessions`
- `getOperation`, `waitOperation`, `waitCheckpoint`, `waitRewind`, `waitFork`
- `connectCDP`

`iterateCheckpoints` is lazy and fetches one page at a time. The list method
accepts `limit`, opaque `cursor`, `lifecycle`, and `durability` filters.

Every waiter accepts a timeout and optional `AbortSignal`. Stopping a waiter
does not cancel work already admitted by the server. The operation-specific
waiters return the same typed result as the corresponding mutation, including
the restored CDP URL after rewind; callers never need to decode raw operation
results. `getOperation` and `waitOperation` remain available for generic
observability.

## Fork and explicit cleanup

```ts
const forked = await brawsr.fork(session.id, checkpoint, {
  n: 3,
  ttlSeconds: 300,
  timeoutMs: 30_000,
});

for (const child of forked.children) {
  const connection = brawsr.connectCDP(child);
  // Each child is an independent session. Attach with your browser library.
  console.log(child.branchIndex, child.sessionId, connection.endpointUrl);
}

const outcomes = await brawsr.closeSessions(forked, { concurrency: 3 });
for (const outcome of outcomes) {
  if (!outcome.ok)
    console.error("close failed", outcome.sessionId, outcome.error);
}
```

The returned children are immutable and ordered by `branchIndex`. The source
session remains open. Children may checkpoint, rewind, or fork again; there is
no browser-state merge. `closeSessions` never selects a winner, closes the
source, or hides partial failures. It accepts a fork result, child objects, or
session IDs and preserves input order in its outcome list.

## Errors and recovery

- `BrawsrApiError`: safe API envelope with `status`, stable `code`,
  `requestId`, optional `operationId`, `retryable`, and `retryAfterMs`.
- `BrawsrOperationError`: the server operation reached `failed`.
- `BrawsrWaitTimeoutError` / `BrawsrWaitCancelledError`: local waiting stopped;
  server work may still complete. For an admitted mutation, `operationId` and
  `idempotencyKey` remain available programmatically for recovery.
- `BrawsrTransportError`: the transport outcome is ambiguous. Its
  `idempotencyKey` is available programmatically for recovery but is omitted
  from the message.

The client does not retry an ambiguous mutation by default. Advanced callers
may provide `isPreResponseConnectionError`; only a definitely pre-response
failure is retried, at most once, with the same idempotency key.

Resume a timed-out rewind without resending it:

```ts
try {
  await brawsr.rewind(session.id, checkpoint, { timeoutMs: 1_000 });
} catch (error) {
  if (!(error instanceof BrawsrWaitTimeoutError) || !error.operationId)
    throw error;
  const restored = await brawsr.waitRewind(error.operationId, {
    timeoutMs: 30_000,
  });
  const connection = brawsr.connectCDP(restored);
  await chromium.connectOverCDP(connection.endpointUrl, {
    headers: connection.headers,
  });
}
```

Rewind restores browser/client state, not side effects already committed by a
remote website. Long-lived WSS, SSE, or WebRTC connections may need
application-level reconnection after restore.

See `examples/rewind-playwright.ts` and `examples/rewind-puppeteer.ts` for
executable reconnect stories that reject stale page handles and rediscover the
restored pages. A classic Selenium WebDriver session cannot be rebound to the
replacement browser in v0.1; a later WebDriver/BiDi adapter owns that contract.

## Development

```bash
npm ci
npm run typecheck
npm run typecheck:examples
npm run build
npm test
npm run verify:package
```

The package check uses the release-pinned Node 20 + npm 10.8.2 toolchain,
builds the archive twice, compares contents and SHA-256, and imports the SDK
from a clean temporary archive install. Use Node 20 for this release-only gate;
the installed SDK remains supported on newer Node versions.
